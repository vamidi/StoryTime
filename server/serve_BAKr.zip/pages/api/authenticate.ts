// Fake users data
import { NextApiRequest, NextApiResponse } from 'next';

import { firebase } from '../../config/firebase-config';

interface IUser
{
	id: number;
}

const users: IUser[] = [{ id: 1 }, { id: 2 }, { id: 3 }]

export default function handler(req: NextApiRequest, res: NextApiResponse<IUser[]>)
{
	if(req.method === 'POST')
	{
		const { email, password } = req.body;
		console.log(email, password); // this returns an empty object, why??

		firebase.auth().signInWithEmailAndPassword(email, password).then(() =>
		{
			firebase.auth().onAuthStateChanged(function (user) {
				console.log(user.getIdTokenResult());
			});
		});

	}

	// Get data from your database
	res.status(200).json(users)
}

const config = {
    pageExtensions: ['js', 'jsx', 'ts', 'tsx'],
};

module.exports = config;

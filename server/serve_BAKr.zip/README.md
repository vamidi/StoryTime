# StoryTime server 2020.1.3f1

## Requirements

* Make sure you have Node version >= 10.0 and (NPM >= 5 or Yarn ) [url](https://nodejs.org/en/download/)
* Your game engine of choice where you can receive JSON from the API.
* A Firebase project free or blaze tier.
* A web host to communicate with Firebase and return JSON data to your framework/engine.

## Template includes
- Typescript
- Next.js
- CI/CD
- Jest tests
- SSL (via Vercel Now)
- Google Analytics

## How to use
```sh
# install Vercel globally
npm i -g vercel

# clone our repo
git clone https://github.com/vamidi/StoryTime.git

# change directory to our repo server
cd storytime/server

# install the repo with npm
npm install

# run app in development
npm run dev

```

export default () => (
	<div>Welcome to StoryTime web server!</div>
);

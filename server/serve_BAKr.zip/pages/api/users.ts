// Fake users data
import { NextApiResponse } from 'next';

import { fire } from '../../config/firebase-config';

interface IUser
{
	id: number;
}

const users: IUser[] = [{ id: 1 }, { id: 2 }, { id: 3 }]

export default function handler(_: any, res: NextApiResponse<IUser[]>) {
	console.log(fire, "here");
	// Get data from your database
	res.status(200).json(users)
}

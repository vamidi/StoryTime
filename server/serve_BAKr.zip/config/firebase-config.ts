// config/fire-config.js

import * as firebase from 'firebase/app';
import 'firebase/auth';

const firebaseConfig = {
	apiKey: "AIzaSyC05Pn4eiFjs0fvahifUsciggpwyw0Xj9M",
	authDomain: "buas-prototype-dev.firebaseapp.com",
	databaseURL: "https://buas-prototype-dev.firebaseio.com",
	projectId: "buas-prototype-dev",
	storageBucket: "buas-prototype-dev.appspot.com",
	messagingSenderId: "208597693892",
	appId: "1:208597693892:web:96cdbeab92979115b7e091"
};
try {
	firebase.initializeApp(firebaseConfig);
} catch(err){
	if (!/already exists/.test(err.message)) {
		console.error('Firebase initialization error', err.stack)}
}
export { firebase };
